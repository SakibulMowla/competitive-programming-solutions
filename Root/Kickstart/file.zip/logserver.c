/* logserver.c -- implementation of the log server */
#include <signal.h>
#include "logservice.h"

int main()
{
	printf("Please make me useful!\n");

	return 0;
}
