/* logclient.c -- implements a simple log service client */
#include "logservice.h"

int main(int argc,char**argv)
{
	printf("Make me useful too!\n");

	return 0;
}

