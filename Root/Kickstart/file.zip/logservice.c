/* logservice.c -- implementation of the log service */
#include "logservice.h"

int logServiceInit()
{
	int id;

	return id;

}

int logMessage(int serviceId,char*message)
{
	int rv;

	return rv;
}
