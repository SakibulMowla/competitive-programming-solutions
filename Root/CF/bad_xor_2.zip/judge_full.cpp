#include <bits/stdc++.h>
using namespace std;

#define LL  long long
#define mod 1000000007

bool isBad[515];
LL dp[101][515][2];
int val[101], next_sibling[101], pre[101];

vector < int > edge[101];


// solution code starts here
LL go(int node, int xor_val, int fl, int parent){
    LL &ret = dp[node][xor_val][fl];
    if(ret != -1) return ret;
    ret = 0;

    if(fl == 0){
        xor_val ^= val[node];

        if(node == 1 && edge[node].size() > 0){
            ret = (ret + go(edge[node][0], xor_val, 1, node)) % mod;
        } else if(edge[node].size() > 1){
            ret = (ret + go(edge[node][1], xor_val, 1, node)) % mod;
        } else {
            if(xor_val == 0) ret = (ret + 1) % mod;
        }

    } else {
        if(next_sibling[node] == -1){

            if(xor_val == 0) ret = (ret + 1) % mod;
            ret = (ret + go(node, xor_val, 0, parent)) % mod;

        } else {

            ret = (ret + go(next_sibling[node], xor_val, 1, parent)) % mod;
            for(int i = 0; i < 512; i++){
                ret = (ret + go(node, xor_val ^ i, 0, parent) *
                         go(next_sibling[node], i, 1, parent)) % mod;
            }

        }

    }

    return ret;
}

void dfs(int node, int parent){
    pre[node] = parent;
    for(int i = 0; i < edge[node].size(); i++){
        if(edge[node][i] == parent) swap(edge[node][i], edge[node][0]);
    }

    int last = 1;
    if(node == 1) last = 0;
    for(int i = edge[node].size() - 2; i >= last; i--){
        next_sibling[ edge[node][i] ] = edge[node][i+1];
    }
    for(int i = last; i < edge[node].size(); i++){
        dfs(edge[ node ][i], parent);
    }
}
// solution part ends

// code for checking input
int father[101];
int Find(int x){
    if(x == father[x]) return x;
    return father[x] = Find(father[x]);
}

int main(){
    freopen("large.in", "r", stdin);
    freopen("large-1.out", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0);
    int T; cin >> T;
    for(int ts = 1; ts <= T; ts++){
        // 1 <= N <= 100, M is at most 501
        int N, M; cin >> N >> M;
        assert(1 <= N && N <= 100);
        assert(0 <= M && M <= 501);

        // clear up the memory
        for(int i = 1; i <= N; i++){
            edge[i].clear();
            father[i] = i;
        }
        memset(isBad, 0, sizeof isBad);
        memset(next_sibling, -1, sizeof next_sibling);
        memset(dp, -1, sizeof dp);

        for(int i = 1; i < N; i++){
            int x, y; cin >> x >> y;
            edge[x].push_back(y);
            edge[y].push_back(x);

            int px = Find(x), py = Find(y);
            assert(px != py);
            father[px] = py;

        }
        for(int i = 1; i <= N; i++){
            cin >> val[i];
        }
        for(int i = 1; i <= M; i++){
            int x; cin >> x;
            assert(0 <= x && x <= 500);
            assert(isBad[x] == false);

            isBad[x] = true;
        }

        dfs(1, 0);

        LL res = 0;
        for(int i = 1; i <= N; i++){
            for(int j = 0; j < 512; j++){
                if(isBad[j] == false) {
                    res = (res + go(i, j, 0, pre[i])) % mod;
                }
            }
        }

        cout << "Case " << ts << ": " << res << endl;
    }
}
