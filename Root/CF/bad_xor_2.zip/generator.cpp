#include <bits/stdc++.h>

using namespace std;

#define xx         first
#define yy         second
#define pb         push_back
#define mp         make_pair
#define LL         long long
#define inf        INT_MAX/3
#define mod        1000000007ll
#define PI         acos(-1.0)
#define linf       (1ll<<60)-1
#define FOR(I,A,B) for(int I = (A); I < (B); ++I)
#define REP(I,N)   FOR(I,0,N)
#define ALL(A)     ((A).begin(), (A).end())
#define set0(ar)   memset(ar,0,sizeof ar)
#define vsort(v)   sort(v.begin(),v.end())
#define setinf(ar) memset(ar,126,sizeof ar)

//cout << fixed << setprecision(20) << p << endl;

template <class T> inline T bigmod(T p,T e,T M){
    LL ret = 1;
    for(; e > 0; e >>= 1){
        if(e & 1) ret = (ret * p) % M;
        p = (p * p) % M;
    } return (T)ret;
}
template <class T> inline T gcd(T a,T b){if(b==0)return a;return gcd(b,a%b);}
template <class T> inline T modinverse(T a,T M){return bigmod(a,M-2,M);}


/*
generation plan:
2 tests of 1 node
    res 0/1
4 tests of line
    0 -> 10 -> 100 -> 501
4 tests of 1 depth
    0 -> 10 -> 100 -> 501
10 random tests
*/

void generate_tree(int n){
    for(int i = 1; i <= n; i++){
        cout << rand() % 501 << " ";
    }
    cout << endl;
}

void generate_M(int m){
    int ar[501] = {0};
    int cnt = 0;
    FOR(i, 1, m + 1){
        int v = rand() % (501 - cnt);
        for(int j = 0; j < 501; j++){
            if(ar[j]) continue;
            if(v == 0) {
                cout << j << " ";
                ar[j] = 1;
                cnt++;
                break;
            }
            v--;
        }
    }
    cout << endl;
}

int main() {
    ios_base::sync_with_stdio(0); cin.tie(0);
    freopen("large.in", "w", stdout);
    int MX = 100;

    cout << 20 << endl;

    // 2 tests of 1 node
    cout << "1 1" << endl;
    cout << 1 << endl;
    cout << 0 << endl;

    cout << "1 1" << endl;
    cout << 1 << endl;
    cout << 1 << endl;

    // 4 tests of line
    cout << MX << " " << 0 << endl;
    FOR(i, 1, MX) cout << i << " " << i+1 << endl;
    generate_tree(MX);
    generate_M(0);

    cout << MX << " " << 10 << endl;
    FOR(i, 1, MX) cout << i << " " << i+1 << endl;
    generate_tree(MX);
    generate_M(10);

    cout << MX << " " << 100 << endl;
    FOR(i, 1, MX) cout << i << " " << i+1 << endl;
    generate_tree(MX);
    generate_M(100);

    cout << MX << " " << 500 << endl;
    FOR(i, 1, MX) cout << i << " " << i+1 << endl;
    generate_tree(MX);
    generate_M(500);

    // 4 tests of depth 1
    cout << MX << " " << 0 << endl;
    FOR(i, 2, MX + 1) cout << i << " " << 1 << endl;
    generate_tree(MX);
    generate_M(0);

    cout << MX << " " << 10 << endl;
    FOR(i, 2, MX + 1) cout << i << " " << 1 << endl;
    generate_tree(MX);
    generate_M(10);

    cout << MX << " " << 100 << endl;
    FOR(i, 2, MX + 1) cout << i << " " << 1 << endl;
    generate_tree(MX);
    generate_M(100);

    cout << MX << " " << 500 << endl;
    FOR(i, 2, MX + 1) cout << i << " " << 1 << endl;
    generate_tree(MX);
    generate_M(500);

    // 10 tests
    FOR(t, 1, 11){
        int v = rand() % 201;
        cout << MX << " " << v << endl;
        FOR(i, 1, MX){
            int p = rand() % i;
            cout << i+1 << " " << p+1 << endl;
        }
        generate_tree(MX);
        generate_M(v);
    }
}
