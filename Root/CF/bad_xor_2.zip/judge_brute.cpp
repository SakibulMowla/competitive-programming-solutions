#include <bits/stdc++.h>
using namespace std;

#define LL  long long
#define mod 1000000007

bool isBad[515];
pair < int, int > edge[101];
int val[101];


// code for checking input
int father[101];
int Find(int x){
    if(x == father[x]) return x;
    return father[x] = Find(father[x]);
}

int main(){
    freopen("small.in", "r", stdin);
    freopen("small-1.out", "w", stdout);
    ios_base::sync_with_stdio(0); cin.tie(0);
    int T; cin >> T;
    for(int ts = 1; ts <= T; ts++){
        // 1 <= N <= 100, M is at most 501
        int N, M; cin >> N >> M;
        assert(1 <= N && N <= 100);
        assert(0 <= M && M <= 501);

        // clear up the memory
        for(int i = 1; i <= N; i++){
            father[i] = i;
        }
        memset(isBad, 0, sizeof isBad);

        for(int i = 1; i < N; i++){
            int x, y; cin >> x >> y;
            edge[i] = make_pair(x, y);

            int px = Find(x), py = Find(y);
            assert(px != py);
            father[px] = py;

        }
        for(int i = 1; i <= N; i++){
            cin >> val[i];
        }
        for(int i = 1; i <= M; i++){
            int x; cin >> x;
            assert(0 <= x && x <= 500);
            assert(isBad[x] == false);

            isBad[x] = true;
        }

        int res = 0;
        for(int i = 1; i < (1<<N); i++){
            for(int j = 1; j <= N; j++) father[j] = j;
            for(int j = 1; j < N; j++){
                if((i & 1<<(edge[j].first-1)) == 0) continue;
                if((i & 1<<(edge[j].second-1)) == 0) continue;

                int px = Find(edge[j].first), py = Find(edge[j].second);
                father[px] = py;
            }

            int parent = 0, fl = 0, xor_val = 0;
            for(int j = 1; j <= N; j++){
                if(i & 1<<(j-1)){
                    xor_val ^= val[j];
                    if(parent == 0) parent = Find(j);
                    else if(parent != Find(j)) fl = 1;
                }
            }
            if(fl == 0 && isBad[xor_val] == false){
                res++;
            }
        }

        cout << "Case " << ts << ": " << res << endl;
    }
}
